#coding:utf-8
import sys
sys.path.append("..")
from JsFunction import *

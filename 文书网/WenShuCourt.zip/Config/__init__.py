from Config import *
import sys
sys.path.append("..")
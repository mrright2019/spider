#coding:utf-8

from Saver import *
import requests
from Config import *
import os
import time
import threading
import MySQLdb

NotId = 1
ExistId = 2
DownError=0

lock = threading.Lock()

class DbHelper(object):
	def __init__(self):
		self.redis = SaverRedis("35.220.199.242")
		self.mysql = MySQLdb.connect("35.220.199.242","root","123456","WenShuId" )
		self.mysql_cur = self.mysql.cursor()

	def exists_id(self,docid):
		sql = "select * from DocId where docid = '" +docid+"'"
		lock.acquire()
		try:
			self.mysql_cur.execute(sql)
			res = self.mysql_cur.fetchone()
		except:
			res = None
		lock.release()
		if res is None:
			return False
		return True

	def save_docid(self,docid):
		sql = "insert into DocId(docid) values('"+docid+"');"
		# print sql
		lock.acquire()
		try:
			self.mysql_cur.execute(sql)
			self.mysql.commit()
		except:
			self.mysql.rollback()
		lock.release()

dbh = DbHelper()

def download(docid):
	print(docid)
	if docid is None or len(docid)<20:
		return NotId
	if dbh.exists_id(docid):
		return ExistId
	url = 'http://wenshu.court.gov.cn/CreateContentJS/CreateContentJS.aspx?DocID='+docid
	try:
		cont = requests.get(url,headers=ListHeaders,timeout=60)
	except Exception,e:
		print "request error"
		print e
		dbh.redis.save(docid)
		# exit()
		return DownError
	if cont.status_code == 200:
		f = open("Doc/"+docid+".js","w")
		f.write(cont.content)
		f.close()
		dbh.save_docid(docid)
	else:
		print cont
		print cont.text
		print "download error"
		dbh.redis.save(docid)
		# exit()

# dbh.save_docid(dbh.redis.get_one())

def dn():
	while True:
		download(dbh.redis.get_one())



works = []

for i in range(10):
	t = threading.Thread(target=dn)
	t.start()
	works.append(t)

for t in works:
	t.join()
